# Data Dictionary

## data/kushtha_types.csv

| Field | Description |
|---|---|
| `id` | Stable identifier (K01, K02, ...). Never reused. |
| `sanskrit_name` | IAST-style transliteration without diacritics (diacritic form can be added later). |
| `category` | `Maha` or `Kshudra`. |
| `classical_source` | Text and chapter the enumeration comes from. Must match an entry in `references.csv`. |
| `dosha_predominance` | Dosha attribution as stated in the cited source. Leave blank until verified. Different Samhitas may differ; add a separate row or note. |
| `classical_features_summary` | Short paraphrase of lakshana. Do not paste long verbatim passages from copyrighted editions. |
| `modern_correlation_tentative` | Proposed modern diagnosis, suffixed `(proposed)`. Needs a literature citation before it is treated as established. |
| `verification_status` | `needs_verification`, `verified_primary`, or `verified_secondary`. |

## data/references.csv

| Field | Description |
|---|---|
| `ref_id` | Stable identifier (R01, ...). |
| `text` | Samhita or treatise. |
| `chapter` | Sthana and adhyaya. |
| `author_or_commentator` | Author, and commentator if a commentary is used. |
| `edition` | Edition, translator, and publisher used. |
| `notes` | Free text. |

## Conventions

- One verified fact per cell; record disagreements between sources as separate rows or notes.
- Never mark a record `verified_primary` without a verse-level reference.
- UTF-8, comma-separated, quoted where a field contains commas.
