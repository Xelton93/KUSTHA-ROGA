#!/usr/bin/env python3
"""Validate data/kushtha_types.csv against the data dictionary."""
import csv
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
REQUIRED = [
    "id", "sanskrit_name", "category", "classical_source",
    "dosha_predominance", "classical_features_summary",
    "modern_correlation_tentative", "verification_status",
]
CATEGORIES = {"Maha", "Kshudra"}
STATUSES = {"needs_verification", "verified_primary", "verified_secondary"}


def main() -> int:
    errors = []
    with open(ROOT / "data" / "kushtha_types.csv", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != REQUIRED:
            errors.append(f"Header mismatch: {reader.fieldnames}")
        rows = list(reader)

    ids = set()
    counts = {"Maha": 0, "Kshudra": 0}
    for n, row in enumerate(rows, start=2):
        if not re.fullmatch(r"K[0-9]{2,}", row["id"]):
            errors.append(f"line {n}: bad id {row['id']!r}")
        if row["id"] in ids:
            errors.append(f"line {n}: duplicate id {row['id']}")
        ids.add(row["id"])
        if row["category"] not in CATEGORIES:
            errors.append(f"line {n}: bad category {row['category']!r}")
        else:
            counts[row["category"]] += 1
        if row["verification_status"] not in STATUSES:
            errors.append(f"line {n}: bad verification_status")
        if row["verification_status"] == "verified_primary" and not row["dosha_predominance"]:
            errors.append(f"line {n}: verified_primary but dosha_predominance empty")

    if counts != {"Maha": 7, "Kshudra": 11}:
        errors.append(f"Expected 7 Maha and 11 Kshudra (Charaka), got {counts}")

    if errors:
        print("\n".join(errors))
        return 1
    print(f"OK: {len(rows)} records ({counts['Maha']} Maha, {counts['Kshudra']} Kshudra)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
